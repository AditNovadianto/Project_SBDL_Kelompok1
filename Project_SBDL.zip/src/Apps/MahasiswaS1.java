package Apps;
public class MahasiswaS1 extends Mahasiswa {
    private String jalurMasuk;
    private String dosenPembimbing;

    public String getJalurMasuk() {
        return jalurMasuk;
    }

    public void setJalurMasuk(String jalurMasuk) {
        this.jalurMasuk = jalurMasuk;
    }

    public String getDosenPembimbing() {
        return dosenPembimbing;
    }

    public void setDosenPembimbing(String dosenPembimbing) {
        this.dosenPembimbing = dosenPembimbing;
    }

}
