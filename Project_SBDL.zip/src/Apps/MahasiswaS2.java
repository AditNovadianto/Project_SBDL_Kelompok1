package Apps;
public class MahasiswaS2 extends Mahasiswa {
    private String jalurMasuk;
    private String dosenPembimbing;
    private String asalUniv;

    public String getJalurMasuk() {
        return jalurMasuk;
    }

    public void setJalurMasuk(String jalurMasuk) {
        this.jalurMasuk = jalurMasuk;
    }

    public String getDosenPembimbing() {
        return dosenPembimbing;
    }

    public void setDosenPembimbing(String dosenPembimbing) {
        this.dosenPembimbing = dosenPembimbing;
    }

    public String getAsalUniv() {
        return asalUniv;
    }

    public void setAsalUniv(String asalUniv) {
        this.asalUniv = asalUniv;
    }

}
